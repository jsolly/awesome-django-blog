<!--
Welcome to resume.lol !

This is the template you can use to get started.

More documentation can be found in the docs section
>>> https://resume.lol/docs
-->
@REDACTED=false
@NAME=John Solly||Hidden Name
@ROLE=Senior Geospatial Developer
@EMAIL= jsolly@pm.me||fake@email.com
@PHONE= 279.321.2870||(555) 123-5555
@WEBSITE=blogthedata.com||example.com
@LOCATION=Redlands, CA

# {NAME}
<span class="my-role">*{ROLE}*</span>

<div class="section headerInfo">

- [{EMAIL}](mailto:{EMAIL})
- {PHONE}
- [{WEBSITE}](https://{WEBSITE})
- {LOCATION}

</div>

## Tech Stack
<b>Languages</b>: Python | TypeScript | Golang | SQL/NoSQL | Shell/Bash

<b>Web Development</b>: | Apache | Cloudflare | LLMs | CI/CD | GitHub Actions

<b>DevOps & Cloud</b>: Docker | Terraform | GitHub Actions | Jenkins | Serverless

<b>Geospatial</b>: PostGIS | GeoPandas | GDAL | Dask | ArcPy | Mapbox GL | Turf.js | Leaflet

## Professional Experience

### Senior Geospatial Developer, University of Maryland <span class="spacer"></span> Sept 2022 &mdash; Present

- Mentor an agile team of four engineers, providing technical guidance and helping grow their technical skills.
- Architect ETL pipelines for loading, analyzing, and retrieving 300TB+ of COG and ZARR data into decentralized storage systems and databases.
- Design open-source APIs and libraries to expose geospatial data to front-end web clients and desktop GIS applications (QGIS and ArcPro).
- Author dozens of tutorial Python Jupyter notebooks to educate developer audiences on the functionality of our geospatial tools.
- Gave presentations at Concensus 2023, Compute Over Data summit (2023), available on YouTube

### Integration Consultant, YellowfinBI <span class="spacer"></span> May 2021 &mdash; Feb 2022

- Designed innovative data solutions using Yellowfin's REST, SOAP, and JavaScript APIs for Yellowfin's largest clients.
- Troubleshoot and resolve complex L3 production issues within cloud, on-prem, and hybrid infrastructure (Proxies, Docker, K8, Load Balancers).
- Led the migration of Yellowfin's largest partner to Yellowfin 9, upgrading from a legacy deployment

### Product Engineer, Esri | ArcGIS Dashboards <span class="spacer"></span> May 2017 &mdash; May 2021

- Created automated regression testing harness for a JavaScript-based web application using Python, Selenium, Docker, and Jenkins revealing hundreds of defects. Reduced manual testing from 240 to 100 hours each quarter for offshore testing teams.
- Managed numerous Dashboard releases as the Release Coordinator, ensuring high quality releases with no production hotfixes over four years.

<!-- Older resume bits can be commented out so that you can keep the info without deleting it -->

<!-- ### <span>Software Engineering Intern, Google</span> <span>Mar 2017 &mdash; Sept 2017</span>

### <span>Software Engineering Intern, Curalate</span> <span>June 2016 &mdash; Sept 2016</span> -->

## Education

### Computer Science, Bachelors of Science <span class="spacer"></span> Sept 2022 &mdash; May 2026
Open Source Society University (OSSU)

### Geospatial Intelligence, Masters of Science <span class="spacer"></span> Sept 2015 &mdash; May 2017
George Mason University, GPA 3.93
### Geoinformation Science, Bachelors of Arts <span class="spacer"></span> Sept 2013 &mdash; May 2015
 University of California, Santa Barbara, GPA 3.85

## Open-Source Projects

- <b>Awesome Django Blog</b> (2021 to Present) A blogging platform with user authentication, SEO optimization, and clean, maintainable TDD code with 100% coverage. My personal blog utilizes this platform and is accessible at blogthedata.com.
- <b>GeoAsteroids</b> (2022 to Present): A modern take on the classic Atari Asteroids game using TypeScript, HTML Canvas, and MongoDB. Leveraged Github Actions CI/CD pipeline for automated testing and deployment. Found at Geoasteroids.com
