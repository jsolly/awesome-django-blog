<!--
Welcome to resume.lol !

This is the template you can use to get started.

More documentation can be found in the docs section
>>> https://resume.lol/docs
-->
@LOCATION=Columbus, OH
@REDACTED=false
@NAME=JOHN SOLLY||Hidden Name
@ROLE=LEAD SOFTWARE ENGINEER
@WEBSITE=blogthedata.com||example.com
@EMAIL= jsolly@pm.me||fake@email.com
@PHONE= 279.321.2870||(555) 123-5555
@LINKEDIN= linkedin.com/in/jsolly/

# {NAME}

<div class="headerInfo">

- {LOCATION}
- {PHONE}
- [{WEBSITE}](https://{WEBSITE})
- [{EMAIL}](mailto:{EMAIL})
- [{LINKEDIN}](https:{LINKEDIN})
</div>

## LEAD SOFTWARE ENGINEER
<div class="role-summary"><b>A strategic and dedicated Senior Software Engineer with a demonstrated history of working with geospatial applications and complex data solutions.</b> A proven leader and mentor with a passion for maintaining the highest code quality standards. Expertise in developing bespoke geospatial applications, owning product implementations, and driving engineering leadership. Well-regarded for documenting well, showing ownership, and excelling as a tech lead with a comprehensive background in software development, databases, web development, and DevOps.
</div>

## AREAS OF EXPERTISE
<p class="skillset-overview">
Software Engineering | Geospatial Technologies & Analytics | Database Management | Design & Performance Tuning | Web Development | Automation | DevOps | Cloud Computing | Serverless Architecture | Agile | Big Data | Data Warehousing and Star Schema | Test-Driven Development (TDD) | Paired Programming | Unit Testing | Decentralized Storage Systems | Technical Writing | Continuous Integration & Continuous Delivery (CI/CD) | Rapid Prototyping & Star Schema | Cross-Functional Leadership Technical Mentorship | ETL Pipeline Architecture | RESTful, SOAP, and JavaScript APIs | Security & Production Issue Resolution Migration & Upgrade Planning | User Authentication & Profile Management | Large Language Models (LLM) | Advanced Algorithm Development | Visualization Tools & Libraries | Quality Assurance | Release Coordination</p>
<br>
<b>Languages</b>: Python | TypeScript | JavaScript | Golang | SQL/NoSQL | Shell/Bash | SQL | Java

<b>Geospatial</b>: PostGIS | GeoPandas | GDAL | Rasterio | Xarray | Dask | ArcPy | ArcGIS | Mapbox GL | Turf.js | Leaflet.js | Maplibre

<b>Databases</b> Postgres | MongoDB | SQLite | MSSQL | MySQL

<b>Web Development</b>: Django | Svelte | React | Vue | Apache | NGINX |Cloudflare | GitHub Actions | Bootstrap | Vite

<b>DevOps & Cloud</b>: Docker Compose | Terraform | GitHub Actions | Jenkins | Serverless | AWS | GCP | SQLalchemy

<b>Product Management</b>  | Jira | Asana | Confluence | Salesforce

## PERFORMANCE HIGHLIGHTS
<div class="performance-highlights">

- <b>Increased Efficiency:</b> Reduced manual testing from 240 to 100 hours each quarter for offshore teams at Esri, achieving a 58% reduction in testing time and improving overall productivity by 140 hours quarterly.

- <b>Innovation</b> in Geospatial Applications: Created custom applications at New Light Technologies and the University of Maryland, managing over 300TB of COG and ZARR data, and innovating cache and retrieval methods for significant savings on infrastructure costs.

- <b>Leadership:</b> Led architecture standards and code quality guidelines for various teams of up to 4 engineers, mentoring and driving innovation and excellence within decentralized cyberinfrastructure development.

- <b>Open-Source Contributions:</b> Developed and maintained significant open-source projects, including GeoAsteroids, utilizing technologies such as TypeScript, MongoDB, and serverless functions; leveraged GitHub Actions CI/CD pipeline for automated testing and deployment.

- <b>Academic Achievements:</b> Achieved second place in a Python-based semantic analysis competition; orchestrated and led numerous workshops, mapathons, and competitions, including an ASPRS funded HOTOSM mapathon event attended by over 100 participants.
</div>

## Professional Experience

### Senior Software Engineer  <span class="spacer"></span> Sept 2023 &mdash; Present
<p class="company-name">New Light Technologies | Washington D.C. (remote)</p>

- Design and deploy scalable cloud-native geospatial applications using best practices to meet key client requirements at NLT.
- Establish software architecture standards and guidelines to improve development efficiency for NLT's geospatial and remote sensing service offerings.

### Senior Geospatial Developer <span class="spacer"></span> Sept 2022 &mdash; Sept 2023
<p class="company-name">EASIER Data Initiative | College Park, MD (Remote)</p>
 
- Led and mentored a team of 4 engineers, focusing on agile practices and technical growth within decentralized cyberinfrastructure development.
- Designed and implemented ETL pipelines to manage 300TB+ of COG and ZARR data, utilizing decentralized storage systems like Filecoin and IPFS.
- Created open-source APIs and libraries for geospatial data, facilitating integration with front-end web clients and desktop GIS applications such as QGIS and ArcPro.
- Authored and presented Python Jupyter notebooks, educating the developer community on geospatial tools through tutorials and key industry events like Consensus 2023 and the Compute Over Data Summit.
- Innovated dynamic cache and retrieval methods, optimizing hot/cold layers to achieve significant savings on infrastructure costs and energy.

### Integration Consultant <span class="spacer"></span> May 2021 &mdash; Feb 2022
<p class="company-name">Yellowfin Business Intelligence | Boise, ID (Remote)</p>

- Empowered developers as a trusted advisor, offering technical leadership in post-sales consulting engagements with tier-1 customers.
- Designed innovative data solutions using Yellowfin’s REST, SOAP, and JavaScript APIs.
- Troubleshot and resolved complex L3 production issues within cloud, on-prem, and hybrid deployments (Proxies, Docker, K8, Load Balancers).
- Authored best practices consultant playbook for Yellowfin's on-prem deployments.

### Software Product Engineer <span class="spacer"></span> May 2017 &mdash; May 2021
<p class="company-name">Environmental Research Institute (Esri) | Redlands, CA</p>

- Created dockerized automated regression testing harness with hundreds of tests for a JavaScript-based web application using Python, Selenium, Jenkins; reduced manual testing from 240 to 100 hours each quarter.
- Authored ArcGIS Dashboard's sanity test plan, uncovering hundreds of defects; led QA for various authentication methods like SAML, LDAP, OAuth, PKI; defined test strategy and negotiated with third-party vendors.
- Completed migration of test cases/plans from spreadsheets to a test management system; responsible for creating and maintaining test assets.
- Served as release manager and scrum master for a team of nine engineers, delegating release tasks to an internal QA team and acting as POC for localization, internationalization, and release teams.
- Handled setup and maintenance of distributed ArcGIS Enterprise deployments with SQL Server and NOSQL-based spatiotemporal data stores.
- Influential in RTL implementation; collected and presented customer analytics in Python to guide decisions.

### Software Product Engineer Intern
- Developed story maps on Zika Virus, custom apps for U.S. Forest Service, web apps for the White House Open Opportunity Project, and ArcGIS tutorials for Congress.
- Demoed ArcPro workflow to students, assisted in Esri's Small Business Specialty Program workshops, and mentored in a collaboration with the USDA.
- Revamped the front-end of a JavaScript mapping application that was shown on the Esri UC stage in front of 14,000 participants.

## Additional Experience & Open-Source Projects
### Graduate Research & Teaching Assistant | George Mason University
- Investigated spatiotemporal patterns in "Team Spatial Cognition," funded by the Army Research Institute; presented findings at the AAG conference.
- Utilized Python for semantic analysis and surface classification; achieved second place in a related competition.
- Collaborated with faculty and organizations, including ASPRS and Mason Mappers, to support and engage students.

### Awesome Django Blog | blogthedata.com
- A blogging platform with user authentication, SEO optimization, and clean, maintainable TDD code with 100% coverage in Vite. My personal blog utilizes this platform and is accessible at blogthedata.com.

### GeoAsteroids | geoasteroids.com
- A modern take on the classic Atari Asteroids game using TS, HTML Canvas, MongoDB, and vercel serverless functions. Leveraged Github Actions CI/CD pipeline for automated testing and deployment. Found at Geoasteroids.com

## Education
<div class="education-section">
<b>Master of Science, Geospatial Intelligence</b> | <b><i>George Mason University</b></i>

<b>Bachelor of Arts, Geoinformation Science</b> | <b><i>University of California, Santa Barbara</i></b> 

<b>Bachelor of Science, Computer Science</b> (In Progress) | <b><i>Open Source Society University (OSSU)</i></b> 
</di